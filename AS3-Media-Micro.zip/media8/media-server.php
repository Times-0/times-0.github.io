<?php

$uri = $_GET['f'];

$url = "http://icer.ink/media8.clubpenguin.com/$uri";

$data = file_get_contents($url);
$headers = get_headers($url, true);

header($headers["Content-Type"]);

$directory = dirname($uri);

if(!is_dir($directory)) {
	mkdir($directory, 0777, true);
}

file_put_contents($uri, $data);

echo $data;

?>