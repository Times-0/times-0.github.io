<?php

file_put_contents("v2/content/local/en/postcards/cool.txt", 'test_data');
?>