<?php

$uri = $_GET['f'];

$url = "https://icer.ink/media1.clubpenguin.com/play/$uri";
file_put_contents("test.txt", "\n$url");

$data = file_get_contents($url);
$headers = get_headers($url, true);

header($headers["Content-Type"]);

$directory = dirname($uri);

if(!is_dir($directory)) {
	mkdir($directory, 0777, true);
}

file_put_contents($uri, $data);

echo $data;

?>