<?php

if(!isset($_GET["file"])) {
	die();
}

function remoteFile($url){
	$ch = curl_init($url);

	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	curl_setopt($ch, CURLOPT_HEADER, TRUE);
	curl_setopt($ch, CURLOPT_NOBODY, TRUE);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	
	curl_exec($ch);
	
	$size = curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
	$mime = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
	
	curl_close($ch);
	
	return array($size, $mime);
}

define("REMOTE_URL", "http://icer.ink/media1.clubpenguin.com/play/");

$uri = $_GET["file"];

if (file_exists($uri))
{
	echo file_get_contents($uri);
	die();
}

$file = substr($uri, 6);
$directory = dirname($file);
$remoteUrl = sprintf("%s%s", REMOTE_URL, $uri);

$fileContent = remoteFile($remoteUrl);
list($fileSize, $mimeType) = $fileContent;

if($fileSize == -1) {
	header("HTTP/1.1 404 Not Found");
} else {
	header("Content-Length: " . $fileSize);
	header("Content-Type: " .  $mimeType);
	file_put_contents('test.txt', $remoteUrl);
	//$fileData = file_get_contents($remoteUrl);
	//echo $fileData;
	
	if(!is_dir($directory)) {
		mkdir($directory, 0777, true);
	}

	$d = implode('/', array_slice(explode('/', $uri), 0, -1)) . '/';
	if (!is_dir($d)) mkdir($d, 0777, true);
	copy($remoteUrl, $uri);
	echo file_get_contents($uri);
	//file_put_contents("$uri", $fileData);
}

?>
