<?php
/* Title : AS3 Phrasechat fix
 * Description : Fix for AS3 chat suggestions module
 * @author : iWaddle
*/                                                 
$objCurl = curl_init();

curl_setopt( $objCurl, CURLOPT_SSL_VERIFYHOST, 0 );
curl_setopt( $objCurl, CURLOPT_SSL_VERIFYPEER, 0 );
curl_setopt( $objCurl, CURLOPT_URL, 'https://api.disney.com/social/autocomplete/v2/search/suggestions?language=' . $_GET[ 'language' ] . '&limit=' . $_GET[ 'limit' ] . '&product=' . $_GET[ 'product' ] . '&text=' . $_GET[ 'text' ] );
curl_setopt( $objCurl, CURLOPT_POST, true );
curl_setopt( $objCurl, CURLOPT_POSTFIELDS, '{}' );
curl_setopt( $objCurl, CURLOPT_HTTPHEADER, array(
    'Host: api.disney.com',
	'Connection: keep-alive',
	'Content-Length: 2',
	'User-Agent: runscope/0.1,Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.116 Safari/537.36',
	'Origin: http://media1.clubpenguin.com',
	'Authorization: FD 08306ECE-C36C-4939-B65F-4225F37BD296:905664F40E29B95CF5810B2ACA85497C7430BB1498E74B52',
	'X-HTTP-Method-Override: GET',
	'Content-Type: application/json',
	'Accept: */*',
	'Referer: http://media1.clubpenguin.com/play/v2/client/phrase_autocomplete.swf?cacheVersion=1397849985',
	'Accept-Encoding: gzip,deflate,sdch',
	'Accept-Language: en-GB,en-US;q=0.8,en;q=0.6'
) );

$strResponse = curl_exec( $objCurl );
print_r( substr( $strResponse, 0, -1 ) );
?>